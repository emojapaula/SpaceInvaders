/* export const NETWORK_CARD_MESSAGE = {
  someNodes: {
    message: 'Some nodes are not mapped',
  },
  allNodes: {
    message: 'All nodes are mapped',
  },
  noNodes: {
    message: 'No nodes mapped',
  },
}; */
export type BUTTON_TYPE = 'primary' | 'ternary' | 'secondary';
// export type SIGNAL_TYPE = 'poor' | 'good' | 'excellent' | 'locked';

/* export const SIGNAL_MESSAGE = {
  poor: {
    message: 'Poor signal',
  },
  good: {
    message: 'Good signal',
  },
  excellent: {
    message: 'Excellent signal',
  },
  locked: {
    message: 'Locked',
  },
};

export const FLOOR_CARD_MESSAGE = {
  red: {
    message: 'Some nodes are not mapped',
  },
  green: {
    message: 'All nodes are mapped',
  },
  blue: {
    message: 'No nodes mapped',
  },
};
 */
