import React, { FC, useState } from 'react';
import { FlatList, ScrollView, TouchableOpacity, View } from 'react-native';
import Container from '../../components/layout/Container';
import { RootStackScreenProps } from '../../navigation/root-navigator';
import { Text } from '../../components/reusable-components/Text';
import Button from '../../components/reusable-components/Button';
import { animalsIcons } from '../../assets/assets.icons';
import styled from 'styled-components';
import { widthPercentageToDP as wp } from 'react-native-responsive-screen';
import { SvgProps } from 'react-native-svg';
import { useAuth } from '../../auth/authContext';

/* const StyledScrollView = styled(FlatList)`
  overflow: visible;
`; */
const StyledScrollView = styled(ScrollView)``;

const ImagesContainer = styled(View)`
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  background-color: lightgray;
  justify-content: space-around;
`;

const ImageContainer = styled(TouchableOpacity)`
  height: 100px;
  width: 100px;
`;

export default function ImageScreen({ navigation }: RootStackScreenProps<'ImageScreen'>) {
  const { chooseImage, signIn } = useAuth();
  return (
    <Container>
      <Text>Image bla</Text>
      <StyledScrollView>
        <ImagesContainer>
          <ImageContainer onPress={() => chooseImage(animalsIcons.panda.name)}>
            <animalsIcons.panda.panda />
          </ImageContainer>
          <ImageContainer>
            <animalsIcons.butterfly.butterfly />
          </ImageContainer>
          <ImageContainer>
            <animalsIcons.chick.chick />
          </ImageContainer>
          <ImageContainer>
            <animalsIcons.crocodile.crocodile />
          </ImageContainer>
          <ImageContainer>
            <animalsIcons.dog.dog />
          </ImageContainer>
          <ImageContainer>
            <animalsIcons.fox.fox />
          </ImageContainer>
          <ImageContainer>
            <animalsIcons.ladybug.ladybug />
          </ImageContainer>
          <ImageContainer>
            <animalsIcons.lion.lion />
          </ImageContainer>
          <ImageContainer>
            <animalsIcons.monkey.monkey />
          </ImageContainer>
          <ImageContainer>
            <animalsIcons.mouse.mouse />
          </ImageContainer>
          <ImageContainer>
            <animalsIcons.octopus.octopus />
          </ImageContainer>
          <ImageContainer>
            <animalsIcons.penguin.penguin />
          </ImageContainer>
          <ImageContainer>
            <animalsIcons.rhino.rhino />
          </ImageContainer>
          <ImageContainer>
            <animalsIcons.snail.snail />
          </ImageContainer>
          <ImageContainer>
            <animalsIcons.snake.snake />
          </ImageContainer>
          <ImageContainer>
            <animalsIcons.tiger.tiger />
          </ImageContainer>
          <ImageContainer>
            <animalsIcons.turtle.turtle />
          </ImageContainer>
          <ImageContainer>
            <animalsIcons.bird.bird />
          </ImageContainer>
        </ImagesContainer>
      </StyledScrollView>

      {/* <StyledScrollView data={images} renderItem={renderItem} numColumns={5} /> */}
      <Button
        onPress={() => {
          signIn();
          console.log('object');
        }}
        type="secondary"
        label="Log In "
      />
    </Container>
  );
}
